import { View, TouchableOpacity, StyleSheet, Text } from 'react-native'
import Icon from 'react-native-vector-icons/MaterialIcons'

export default function CardActions({ icone, title, onPress }) {
	return (
		<View style={styles.conteiner}>
			<TouchableOpacity style={styles.card} onPress={onPress}>
				<Icon style={styles.icon} name={icone} size={80} color="#FFFFFF" />
				<Text style={styles.txtTitle}>{title}</Text>
			</TouchableOpacity>
		</View>
	)
}

const styles = StyleSheet.create({
	conteiner: {
		height: 180,
		width: 200,
		marginRight: 25
	},
	card: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		textAlign: 'center',

		backgroundColor: '#2B1D62',
		borderRadius: 20,

		shadowColor: '#000000',
		shadowOpacity: 0.75,
		elevation: 9,

		padding: 10
	},
	txtTitle: {
		color: 'white',
		fontFamily: 'AveriaLibre',
		fontSize: 26
	}
})
